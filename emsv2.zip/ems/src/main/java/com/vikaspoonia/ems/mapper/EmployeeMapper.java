package com.vikaspoonia.ems.mapper;

import com.vikaspoonia.ems.dto.EmployeeDto;
import com.vikaspoonia.ems.entity.Employee;

public class EmployeeMapper {
    
    //converting Employee data structure to EmployeeDTO data structure to transport 
    // from Server to Client
    public static EmployeeDto maptoEmployeeDTO(Employee employee){
        return new EmployeeDto(
            employee.getId(),
            employee.getFirstName(),
            employee.getLastName(),
            employee.getEmail());
    }

    // Converting DTO data structure to Employee Data structure

    public static Employee mapToEmployee(EmployeeDto employeeDto){
        return new Employee(
            employeeDto.getId(),
            employeeDto.getFirstName(),
            employeeDto.getLastName(),
            employeeDto.getEmail()
        );
    }
}
