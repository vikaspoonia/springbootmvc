package com.vikaspoonia.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vikaspoonia.ems.entity.Employee;

// this will be used in EmployeeServiceImpl
//EmployeeRepository is an interface which inherits property of JpaRepository
//JpaRepository is a class 
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
