package com.emsapplication.emsapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsapplicationApplication.class, args);
	}

}
