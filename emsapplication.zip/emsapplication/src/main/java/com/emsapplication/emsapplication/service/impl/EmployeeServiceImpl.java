package com.emsapplication.emsapplication.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.emsapplication.emsapplication.dto.EmployeeDto;
import com.emsapplication.emsapplication.entity.Employee;
import com.emsapplication.emsapplication.exception.ResourceNotFoundException;
import com.emsapplication.emsapplication.repository.EmployeeRepository;
import com.emsapplication.emsapplication.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    
    private final EmployeeRepository repo;

    public EmployeeServiceImpl(EmployeeRepository repo) {
        this.repo = repo;
    }
    
    @Override
    public List<EmployeeDto> getAllEmployees() {
         return repo.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
       
    }

    @Override
    public EmployeeDto getEmployeeById(Long id) {
      Employee emp = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with id: " + id));

        return mapToDTO(emp);
    }

    @Override
    public EmployeeDto createEmployee(EmployeeDto dto) {
           Employee emp = mapToEntity(dto);
        return mapToDTO(repo.save(emp));
    }

    @Override
    public EmployeeDto updateEmployee(Long id, EmployeeDto dto) {
           Employee emp = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with id: " + id));

        emp.setFirstName(dto.getFirstName());
        emp.setLastName(dto.getLastName());
        emp.setEmail(dto.getEmail());

        return mapToDTO(repo.save(emp));
    }

    @Override
    public void deleteEmployee(Long id) {
         Employee emp = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with id: " + id));

        repo.delete(emp);
    }

//Mapping method

 private EmployeeDto mapToDTO(Employee emp) {
        return new EmployeeDto(
                emp.getId(),
                emp.getFirstName(),
                emp.getLastName(),
                emp.getEmail()
        );
    }

    private Employee mapToEntity(EmployeeDto dto) {
        Employee emp = new Employee();
        emp.setFirstName(dto.getFirstName());
        emp.setLastName(dto.getLastName());
        emp.setEmail(dto.getEmail());
        return emp;
    }
   
}
