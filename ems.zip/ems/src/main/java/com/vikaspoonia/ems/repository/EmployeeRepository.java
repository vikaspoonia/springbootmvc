package com.vikaspoonia.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vikaspoonia.ems.entity.Employee;

// this will be used in EmployeeServiceImpl
//EmployeeRepository is an interface which inherits property of JpaRepository
//JpaRepository is a class 
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
