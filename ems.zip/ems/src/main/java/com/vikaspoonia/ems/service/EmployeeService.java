package com.vikaspoonia.ems.service;

import com.vikaspoonia.ems.dto.EmployeeDto;


public interface EmployeeService {
    // method is defined which accepts EmpoloyeeDTO object which is sent by the client
    EmployeeDto createEmployee(EmployeeDto employeeDto);
}
