package com.vikaspoonia.ems.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vikaspoonia.ems.service.EmployeeService;

import lombok.AllArgsConstructor;


//Handle HTTP request
@AllArgsConstructor
@RestController
@RequestMapping("/api/employees") // base address
public class EmployeeController {
    private EmployeeService employeeService;

    //Build 
}
