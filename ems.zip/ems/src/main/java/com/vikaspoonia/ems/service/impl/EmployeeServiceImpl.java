package com.vikaspoonia.ems.service.impl;

import org.springframework.stereotype.Service;

import com.vikaspoonia.ems.dto.EmployeeDto;
import com.vikaspoonia.ems.entity.Employee;
import com.vikaspoonia.ems.mapper.EmployeeMapper;
import com.vikaspoonia.ems.repository.EmployeeRepository;
import com.vikaspoonia.ems.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    private EmployeeRepository employeeRepository;

    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto){

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        //.save() is a "Two-in-One" tool.
        // If the ID is empty, it adds a new row. If the ID is full, it fixes an old row
        Employee savedEmployee = employeeRepository.save(employee);
        
        return EmployeeMapper.maptoEmployeeDTO(savedEmployee);
        //From here go to package named controller 
        
    }
}
